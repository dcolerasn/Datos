import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Insertar {

	private int num_emp;
	String apellido;
	String oficio;
	int dir;
	String fecha ;
	float salario;
	float comision;
	int dept_no;
	boolean resultado = true;
	public Insertar(String a,String b,String c,String d,String e,String f,String g,String h) throws ClassNotFoundException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo","root","");
			Statement sentencia = conexion.createStatement();
			String sql = String.format("INSERT INTO `empleados` VALUES (%s,'%s','%s',%s,'%s',%s,%s,%s)",a,b,c,d,e,f,g,h);
			sentencia.executeUpdate(sql);
			
			sentencia.close();
			conexion.close();
		}
		catch(SQLException err) {
			System.out.println(err);
			resultado = false;
		}
	}
	public boolean isResultado() {
		return resultado;
	}
	public void setResultado(boolean resultado) {
		this.resultado = resultado;
	}
}