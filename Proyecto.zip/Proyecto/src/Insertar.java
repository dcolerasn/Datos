import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Insertar {

	private int num_emp;
	String apellido;
	String oficio;
	int dir;
	String fecha ;
	float salario;
	float comision;
	int dept_no;
	boolean resultado;
	public Insertar(int a,String b,String c,int d,String e,float f,float g,int h) throws ClassNotFoundException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo","root","");
			Statement sentencia = conexion.createStatement();
			String prueba = "SELECT * FROM empleados WHERE emp_no = '"+a+"'";
			String sql = "INSERT INTO empleados VALUES ('"+a+"','"+b+"','"+c+"','"+d+"','"+e+"','"+f+"','"+g+"','"+h+"';";
			ResultSet r = sentencia.executeQuery(prueba);
			ResultSet resul = sentencia.executeQuery(sql);
			while(r.next()) {
				this.apellido = resul.getString(2);
			}	
			if(apellido!=null) {
				this.resultado=false;
			}
			else {this.resultado=true;}
			
			resul.close();
			sentencia.close();
			conexion.close();
		}
		catch(SQLException err) {}
	}
	public boolean isResultado() {
		return resultado;
	}
	public void setResultado(boolean resultado) {
		this.resultado = resultado;
	}
}