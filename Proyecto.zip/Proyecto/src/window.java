import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import javax.swing.SwingConstants;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Font;
import java.awt.Label;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Choice;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import java.sql.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

public class window {

	private JFrame frame;
	private JTextField textFieldNEmpleado;
	private JTextField textFieldApellido;
	private JTextField textFieldOficio;
	private JTextField textFieldSalario;
	private JTextField textFieldComision;
	private JTextField textFieldFechaAlta;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {

				try {
					window window = new window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void limpiar() {
		textFieldNEmpleado.setText(""); 
		textFieldApellido.setText("");
		textFieldOficio.setText("");
		textFieldSalario.setText("");
		textFieldComision.setText("");
		textFieldFechaAlta.setText("");
		}
	


	/**
	 * Create the application.
	 * @throws ClassNotFoundException 
	 */
	public window() throws ClassNotFoundException {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 * @throws ClassNotFoundException 
	 */
	private void initialize() throws ClassNotFoundException {
		frame = new JFrame();
		frame.setBounds(100, 100, 491, 312);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JComboBox<List<Departamento>> comboBoxDepar = new JComboBox();
		comboBoxDepar.setBounds(314, 97, 150, 22);
		MostrarDepartamentos mostrarDepar = new MostrarDepartamentos(comboBoxDepar);
		panel.add(comboBoxDepar);
		
		JComboBox comboBoxDirector = new JComboBox();
		comboBoxDirector.setBounds(314, 125, 150, 22);
		MostrarDir mostrarDir = new MostrarDir(comboBoxDirector);
		panel.add(comboBoxDirector);
		
		JLabel label1 = new JLabel("    GESTI�N DE EMPLEADOS");
		label1.setBounds(0, 11, 434, 19);
		label1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		label1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(label1);
		
		Label labelNEmpleado = new Label("N\u00BA EMPLEADO:");
		labelNEmpleado.setBounds(10, 68, 105, 22);
		panel.add(labelNEmpleado);
		
		Label labelApellido = new Label("APELLIDO:");
		labelApellido.setBounds(20, 97, 62, 22);
		panel.add(labelApellido);
		
		Label labelOficio = new Label("OFICIO:");
		labelOficio.setBounds(20, 125, 62, 22);
		panel.add(labelOficio);
		
		Label labelSalario = new Label("SALARIO:");
		labelSalario.setBounds(20, 153, 62, 22);
		panel.add(labelSalario);
		
		Label labelComision = new Label("COMISI\u00D3N:");
		labelComision.setBounds(20, 181, 81, 22);
		panel.add(labelComision);
		
		textFieldNEmpleado = new JTextField();
		textFieldNEmpleado.setBounds(119, 68, 86, 20);
		panel.add(textFieldNEmpleado);
		textFieldNEmpleado.setColumns(10);
		
		textFieldApellido = new JTextField();
		textFieldApellido.setBounds(119, 99, 146, 20);
		panel.add(textFieldApellido);
		textFieldApellido.setColumns(10);
		
		textFieldOficio = new JTextField();
		textFieldOficio.setColumns(10);
		textFieldOficio.setBounds(119, 127, 146, 20);
		panel.add(textFieldOficio);
		
		textFieldSalario = new JTextField();
		textFieldSalario.setBounds(119, 155, 86, 20);
		panel.add(textFieldSalario);
		textFieldSalario.setColumns(10);
		
		textFieldComision = new JTextField();
		textFieldComision.setBounds(119, 183, 86, 20);
		panel.add(textFieldComision);
		textFieldComision.setColumns(10);
		
		JList list = new JList();
		list.setBounds(433, 156, -109, -30);
		panel.add(list);
		
		textFieldFechaAlta = new JTextField();
		textFieldFechaAlta.setBounds(314, 183, 86, 20);
		panel.add(textFieldFechaAlta);
		textFieldFechaAlta.setColumns(10);
		
		Label label = new Label("FECHA ALTA:");
		label.setBounds(228, 181, 86, 22);
		panel.add(label);
		
		Label label_1 = new Label("yyyy-MM-dd");
		label_1.setFont(new Font("Dialog", Font.PLAIN, 9));
		label_1.setBounds(402, 181, 62, 22);
		panel.add(label_1);
		
		JButton btnConsultar = new JButton("CONSULTAR EMPLEADO");
		btnConsultar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String num_emp = textFieldNEmpleado.getText();
				int num = Integer.parseInt(num_emp);
				try {
					Consultar consulta = new Consultar(num);
					if(consulta.isResultado()==false) {
						JOptionPane.showMessageDialog(btnConsultar, "El empleado seleccionado no existe");
						limpiar();
					}
					else {
					textFieldApellido.setText(consulta.getApellido());
					textFieldOficio.setText(consulta.getOficio());
					textFieldSalario.setText(consulta.getSalario());
					textFieldComision.setText(consulta.getComision());
					textFieldFechaAlta.setText(consulta.getFecha());
					comboBoxDepar.setSelectedItem(1);
					}
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				
			}
		});
		btnConsultar.setBounds(244, 68, 220, 23);
		panel.add(btnConsultar);
		
		JButton btnInsertar = new JButton("INSERTAR");
		btnInsertar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int no = Integer.parseInt(textFieldNEmpleado.getText());
				String apellido = textFieldApellido.getText();
				String oficio = textFieldOficio.getText();
				String dir = String.valueOf(comboBoxDirector.getSelectedItem());
				int director = Integer.parseInt(dir.substring(0,3));
				String fecha = "2020-03-08";
				
				float salario = Float.parseFloat(textFieldSalario.getText());
				float comision = Float.parseFloat(textFieldComision.getText());
				String dep = String.valueOf(comboBoxDepar.getSelectedItem());
				int departamento = Integer.parseInt(dep.substring(0,2));
				try {
					Insertar insert = new Insertar(no,apellido,oficio,director,fecha,salario,comision,departamento);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnInsertar.setBounds(40, 209, 116, 23);
		panel.add(btnInsertar);
		
		JButton btnEliminar = new JButton("ELIMINAR");
		btnEliminar.setBounds(178, 209, 116, 23);
		panel.add(btnEliminar);
		
		JButton btnModificar = new JButton("MODIFICAR");
		btnModificar.setBounds(314, 209, 116, 23);
		panel.add(btnModificar);
		
		JButton btnSalir = new JButton("SALIR");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 
			}
		});
		btnSalir.setBounds(108, 238, 116, 23);
		panel.add(btnSalir);
		
		JButton btnLimpiar = new JButton("LIMPIAR");
		btnLimpiar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiar();
			}
		});
		btnLimpiar.setBounds(245, 238, 116, 23);
		panel.add(btnLimpiar);
		


	}


	
}
