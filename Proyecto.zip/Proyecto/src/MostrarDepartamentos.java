import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import javax.swing.JComboBox;

public class MostrarDepartamentos {

	

	public MostrarDepartamentos(JComboBox jc) throws ClassNotFoundException {
	try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo","root","");
			Statement sentencia = conexion.createStatement();
			String sqlDepar = "SELECT dept_no,dnombre FROM departamentos WHERE 1";
			String sqlDir = "SELECT emp_no,apellido FROM empleados WHERE 1;";
			ResultSet resul = sentencia.executeQuery(sqlDepar);
			jc.addItem("Escoje Departamento");
			while(resul.next()) {
				jc.addItem(resul.getString(1)+" / "+resul.getString(2));
			}
			resul.close();
			sentencia.close();
			conexion.close();
	}
	catch(SQLException ex) {
		
	}
	}
}
