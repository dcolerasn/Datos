import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public class Departamento {
	private String dep_no;
	private String dnombre;

	public String getDep_no() {
		return dep_no;
	}
	public void setDep_no(String dep_no) {
		this.dep_no = dep_no;
	}
	public String getDnombre() {
		return dnombre;
	}
	public void setDnombre(String dnombre) {
		this.dnombre = dnombre;
	}
	public Departamento(String dep_no, String dnombre) {
		super();
		this.dep_no = dep_no;
		this.dnombre = dnombre;
	}

	
}
