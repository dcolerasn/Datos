import java.sql.*;

public class Consultar {

	private int num_emp;
	String apellido;
	String oficio;
	int dir;
	String fecha ;
	float salario;
	float comision;
	int dept_no;
	boolean resultado;
	public Consultar(int e) throws ClassNotFoundException {
		this.num_emp=e;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conexion = DriverManager.getConnection("jdbc:mysql://localhost/ejemplo","root","");
			Statement sentencia = conexion.createStatement();
			String sql = "SELECT * FROM empleados WHERE emp_no = '"+this.num_emp+"';";
			ResultSet resul = sentencia.executeQuery(sql);
			String[] datos = {};
			while(resul.next()) {
				this.apellido = resul.getString(2);
				this.oficio = resul.getString(3);
				this.dir = resul.getInt(4);
				this.fecha = resul.getString(5);
				this.salario = resul.getFloat(6);
				this.comision = resul.getFloat(7);
				this.dept_no = resul.getInt(8);
			}	
			if(apellido==null) {
				this.resultado=false;
			}
			else {this.resultado=true;}
			
			resul.close();
			sentencia.close();
			conexion.close();
		}
		catch(SQLException err) {}
	}
	public boolean isResultado() {
		return resultado;
	}
	public void setResultado(boolean resultado) {
		this.resultado = resultado;
	}
	public int getNum_emp() {
		return num_emp;
	}
	public void setNum_emp(int num_emp) {
		this.num_emp = num_emp;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public String getOficio() {
		return oficio;
	}
	public void setOficio(String oficio) {
		this.oficio = oficio;
	}
	public int getDir() {
		return dir;
	}
	public void setDir(int dir) {
		this.dir = dir;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getSalario() {
		String sal = String.valueOf(salario);
		return sal;
	}
	public void setSalario(float salario) {
		this.salario = salario;
	}
	public String getComision() {
		String com = String.valueOf(comision);
		return com;
	}
	public void setComision(float comision) {
		this.comision = comision;
	}
	public int getDept_no() {
		return dept_no;
	}
	public void setDept_no(int dept_no) {
		this.dept_no = dept_no;
	}
	
}
